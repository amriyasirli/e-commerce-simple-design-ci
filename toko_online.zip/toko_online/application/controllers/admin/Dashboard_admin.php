<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_admin extends CI_Controller {

	
	public function index()
	{
		$data['login'] = $this->model_user->tampil_data()->result();
		$this->load->view('templates_admin/header');
		$this->load->view('templates_admin/topbar');
		$this->load->view('admin/admin');
		$this->load->view('templates_admin/footer');
	}
}
