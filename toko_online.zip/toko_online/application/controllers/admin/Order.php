<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

	
	public function index()
	{
		
		$this->load->view('templates_admin/header');
		$this->load->view('templates_admin/topbar');
		$this->load->view('admin/order');
		$this->load->view('templates_admin/footer');
	}
}
