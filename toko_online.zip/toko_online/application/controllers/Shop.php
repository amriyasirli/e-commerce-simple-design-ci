<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Shop extends CI_Controller {

	
	public function index()
	{
		$data ['barang'] = $this->model_barang->tampil_data()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/topbar');
		$this->load->view('shop', $data);
		$this->load->view('templates/footer');
	}

	public function tambah_keranjang($id)
	{
		$barang = $this->model_barang->find($id);

		$data = array(
			'id'      => $barang->id_brg,
			'qty'     => 1,
			'price'   => $barang->harga,
			'name'    => $barang->nama_brg
			
	);
	
		$this->cart->insert($data);
		redirect('shop');
	
	}
	
	public function tambah_keranjang_detail($id)
	{
		$barang = $this->model_barang->find($id);

		$data = array(
			'id'      => $barang->id_brg,
			'qty'     => 1,
			'price'   => $barang->harga,
			'name'    => $barang->nama_brg
			
	);
	
		$this->cart->insert($data);
		redirect('shop/detail_keranjang/');
	
	}

	public function detail_keranjang()
	{
		$this->load->view('templates/header');
		$this->load->view('templates/topbar');
		$this->load->view('detail_keranjang');
		$this->load->view('templates/footer');
	}

	public function hapus_keranjang()
	{
		$this->cart->destroy();
		redirect('shop/index');
	}

	public function pembayaran()
	{
		$this->load->view('templates/header');
		$this->load->view('templates/topbar');
		$this->load->view('pembayaran');
		$this->load->view('templates/footer');
	}

	public function proses_pembayaran()
	{
		$is_processed = $this->model_invoice->index();
		if($is_processed){
			$this->cart->destroy();
			$this->load->view('templates/header');
			$this->load->view('templates/topbar');
			$this->load->view('proses_pembayaran');
			$this->load->view('templates/footer');
		} else {
			echo "Maaf, pesanan anda gagal di proses. ";
		}
		
	}

	public function detail_barang($id)
	{
		$where = array('id_brg' =>$id);
		$data['barang'] = $this->model_barang->edit_barang($where, 'tb_barang')->result();
		$this->load->view('templates/header');
		$this->load->view('templates/topbar');
		$this->load->view('detail_barang', $data);
		$this->load->view('templates/footer');
	}

	public function tampil_detail()
	{
		$data ['barang'] = $this->model_barang->tampil_data()->result();
		$this->load->view('templates_admin/header');
		$this->load->view('templates_admin/topbar');
		$this->load->view('admin/edit_barang', $data);
		$this->load->view('templates_admin/footer');
	}

}
