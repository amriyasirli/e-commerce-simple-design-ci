<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller {

	
	public function elektronik()
	{
		$data ['elektronik'] = $this->model_kategori->data_elektronik()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/topbar');
		$this->load->view('elektronik', $data);
		$this->load->view('templates/footer');
    }
}