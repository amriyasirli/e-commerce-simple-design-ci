<section class="page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="content">
					<h1 class="page-name">Checkout</h1>
					<ol class="breadcrumb">
						<li><a href="#">Home</a></li>
						<li class="active">checkout</li>
					</ol>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="page-wrapper">
   <div class="checkout shopping">
      <div class="container">
         <div class="row">
            <div class="col-md-8">
               <div class="block billing-details">
                  <h4 class="widget-title">Detail Pengiriman</h4>
                  <form class="checkout-form" method="post" action="<?= base_url('shop/proses_pembayaran') ?>">
                     <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama" placeholder="">
                     </div>
                     <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Contoh : Jln. Minangkabau NO.11, Aur Birugo, Bukittinggi, Sumatera Barat">
                     </div>
                     <div class="checkout-country-code clearfix">
                        <div class="form-group">
                           <label for="telepon">No. Telepon</label>
                           <input type="number" class="form-control" id="telepon" name="telepon" value="">
                        </div>
                        <div class="form-group" >
                           <label for="kode_pos">Kode Pos</label>
                           <input type="number" class="form-control" id="kode_pos" name="kode_pos" value="">
                        </div>
                     </div>
                     <div class="form-group" >
                           <label for="bank">Bank</label>
                           <input type="option" class="form-control" id="bank" name="bank" value="">
                     </div>
                     <button type="submit" class="btn btn-main mt-20">Place Order</button>
                  </form>
               </div>
            </div>
            <div class="col-md-4">
               <div class="product-checkout-details">
                  <div class="block">
                  <?php
                  $no=1;
                  foreach ($this->cart->contents() as $items) : ?>
                  <?php endforeach; ?>
                     <h4>Tagihan</h4>
                     <div class="discount-code">
                        <p>Anda memiliki coupon ? <a data-toggle="modal" data-target="#coupon-modal" href="">Klik disini !</a></p>
                     </div>
                     <ul class="summary-prices">
                        <li>
                           <span>Subtotal :</span>
                           <span class="price">Rp. <?= number_format($this->cart->total(), 0,',','.') ?></span>
                        </li>
                        <li>
                           <span>Ongkos Kirim :</span>
                           <span>Gratis</span>
                        </li>
                     </ul>
                     <div class="summary-total">
                        <?php 
                        $grand_total = 0;
                        if ($keranjang = $this->cart->contents())
                        {
                            foreach ($keranjang as $item)
                            {
                                $grand_total = $grand_total + $item['subtotal'];
                            }
                        echo "<span>Total</span>". "<span>Rp. ". number_format($grand_total, 0,',','.'). "</span>";
                        
                        }
                        else{
                           echo '<a href="<?= base_url(); ?>"" class="btn btn-main mt-20">Lanjutkan belanja.</a>';
                        }
                        ?>
                     </div>
                     <div class="verified-icon">
                        <img src="<?= base_url(); ?>assets/images/shop/verified.png">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

   <!-- Modal -->
   <div class="modal fade" id="coupon-modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-body">
               <form>
                  <div class="form-group">
                     <input class="form-control" type="text" placeholder="Enter Coupon Code">
                  </div>
                  <button type="submit" class="btn btn-main">Apply Coupon</button>
               </form>
            </div>
         </div>
      </div>
   </div>