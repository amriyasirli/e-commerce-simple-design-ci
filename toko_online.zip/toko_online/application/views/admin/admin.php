<section class="user-dashboard page-wrapper">
	<div class="container">
		<div class="row">
			
			<div class="col-md-12">
				<ul class="list-inline dashboard-menu text-center">
					<li><a class="active" href="<?= base_url('admin/dashboard_admin'); ?>">Dashboard</a></li>
					<li><a href="<?= base_url('admin/data_barang'); ?>">Data Barang</a></li>
					<li><a href="<?= base_url('admin/invoice'); ?>">Invoice</a></li>
					<li><a href="<?= base_url('admin/order'); ?>">Order</a></li>
				</ul>

				<div class="dashboard-wrapper user-dashboard">
					<div class="media">
						<div class="pull-left">\
						
							<img class="media-object user-img" src="<?= base_url();?>upload/user/admin.jpg" alt="Image">
						</div>
						<div class="media-body">
							<h2 class="media-heading">Yassirli Amri</h2>
							<p>Selamat datang di halaman <b>Dashboard Admin</b>. Di halaman ini anda bisa memanipulasi data, seperti menambah <b>produk baru</b>, <b>mengganti foto dan nama toko anda</b>, dan juga mengecek <b>orderan</b>. Pastikan hanya anda yang bisa mengakses halaman ini dan orang-orang yang anda percaya. 
								Terima kasih sudah menggunakan sistem kami. Hubungi custumer service jika ada hal yang perlu ditanyakan. Terima Kasih !</p>
						</div>
					</div>
					<div class="total-order mt-20">
						<h4>Total Orders</h4>
						<div class="table-responsive">
							<table class="table">
								<thead>
									<tr>
										<th>Order ID</th>
										<th>Date</th>
										<th>Items</th>
										<th>Total Price</th>
										<th></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td><a href="#">#252125</a></td>
										<td>Mar 25, 2016</td>
										<td>2</td>
										<td>$ 99.00</td>
									</tr>
									<tr>
										<td><a href="#">#252125</a></td>
										<td>Mar 25, 2016</td>
										<td>2</td>
										<td>$ 99.00</td>
									</tr>
									<tr>
										<td><a href="#">#252125</a></td>
										<td>Mar 25, 2016</td>
										<td>2</td>
										<td>$ 99.00</td>
									</tr>
								</tbody>
								
							</table>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>