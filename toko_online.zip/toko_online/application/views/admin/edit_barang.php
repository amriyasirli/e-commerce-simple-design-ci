<section class="page-wrapper">
	<div class="contact-section">
		<div class="container">
			<div class="row">
            <?php foreach ($barang as $brg) : ?>

                <div class="row mt-20">
			<div class="col-md-5">
				<div class="single-product-slider">
					<div id='carousel-custom' class='carousel slide' data-ride='carousel'>
						<div class='carousel-outer'>
							<!-- me art lab slider -->
							<div class='carousel-inner '>
								<div class='item active'>
									<img src='<?= base_url(); ?>assets/images/shop/single-products/product-1.jpg' alt='' data-zoom-image="images/shop/single-products/product-1.jpg" />
								</div>
								<div class='item'>
									<img src='<?= base_url(); ?>assets/images/shop/single-products/product-2.jpg' alt='' data-zoom-image="images/shop/single-products/product-2.jpg" />
								</div>
								
								<div class='item'>
									<img src='<?= base_url(); ?>assets/images/shop/single-products/product-3.jpg' alt='' data-zoom-image="images/shop/single-products/product-3.jpg" />
								</div>
								<div class='item'>
									<img src='<?= base_url(); ?>assets/images/shop/single-products/product-4.jpg' alt='' data-zoom-image="images/shop/single-products/product-4.jpg" />
								</div>
								<div class='item'>
									<img src='<?= base_url(); ?>assets/images/shop/single-products/product-5.jpg' alt='' data-zoom-image="images/shop/single-products/product-5.jpg" />
								</div>
								<div class='item'>
									<img src='<?= base_url(); ?>assets/images/shop/single-products/product-6.jpg' alt='' data-zoom-image="images/shop/single-products/product-6.jpg" />
								</div>
								
							</div>
							
							<!-- sag sol -->
							<a class='left carousel-control' href='#carousel-custom' data-slide='prev'>
								<i class="tf-ion-ios-arrow-left"></i>
							</a>
							<a class='right carousel-control' href='#carousel-custom' data-slide='next'>
								<i class="tf-ion-ios-arrow-right"></i>
							</a>
						</div>
						
						<!-- thumb -->
						<ol class='carousel-indicators mCustomScrollbar meartlab'>
							<li data-target='#carousel-custom' data-slide-to='0' class='active'>
								<img src='<?= base_url(); ?>assets/images/shop/single-products/product-1.jpg' alt='' />
							</li>
							<li data-target='#carousel-custom' data-slide-to='1'>
								<img src='<?= base_url(); ?>assets/images/shop/single-products/product-2.jpg' alt='' />
							</li>
							<li data-target='#carousel-custom' data-slide-to='2'>
								<img src='<?= base_url(); ?>assets/images/shop/single-products/product-3.jpg' alt='' />
							</li>
							<li data-target='#carousel-custom' data-slide-to='3'>
								<img src='<?= base_url(); ?>assets/images/shop/single-products/product-4.jpg' alt='' />
							</li>
							<li data-target='#carousel-custom' data-slide-to='4'>
								<img src='<?= base_url(); ?>assets/images/shop/single-products/product-5.jpg' alt='' />
							</li>
							<li data-target='#carousel-custom' data-slide-to='5'>
								<img src='<?= base_url(); ?>assets/images/shop/single-products/product-6.jpg' alt='' />
							</li>
							<li data-target='#carousel-custom' data-slide-to='6'>
								<img src='<?= base_url(); ?>assets/images/shop/single-products/product-7.jpg' alt='' />
							</li>
						</ol>
					</div>
				</div>
			</div>
				<!-- Contact Form -->
				<div class="contact-form col-md-6 " >
					<form id="contact-form" method="post" action="<?= base_url(). 'admin/data_barang/update/' ?>" role="form">
					
						<div class="form-group">
                        <label for="nama_brg">Nama Barang</label>
                            <input type="hidden" class="form-control" name="id_brg" value="<?= $brg->id_brg ?>">
							<input type="text" class="form-control" name="nama_brg" value="<?= $brg->nama_brg ?>">
                        </div>
                        <div class="form-group">
                        <label for="nama_brg">Keterangan</label>
							<input class="form-control" name="keterangan" value="<?= $brg->keterangan ?>">
                        </div>
                        <div class="form-group">
							<label for="kategori">Kategori</label>
								<select class="form-control" name="kategori" id="kategori">
									<option><?= $brg->kategori ?></option>
									<option>Elektronik</option>
									<option>Pakaian Pria</option>
									<option>Pakaian Wanita</option>
									<option>Aksesoris</option>
								</select>
							</div>
                        <div class="form-group">
                        <label for="nama_brg">Harga</label>
							<input type="number" class="form-control" name="harga" value="<?= $brg->harga ?>">
                        </div>
                        
						<div class="form-group">
                        <label for="nama_brg">Stok</label>
							<input type="number"  class="form-control" name="stok" value="<?= $brg->stok ?>">
						</div>
						
						<div id="cf-submit">
							<button type="submit" id="contact-submit" class="btn btn-main">Submit
						</button>						
						
					</form>
                </div>

                <?php endforeach; ?>
				<!-- ./End Contact Form -->
				
				<!-- / End Contact Details -->
					
				
			
			</div> <!-- end row -->
		</div> <!-- end container -->
	</div>
</section>