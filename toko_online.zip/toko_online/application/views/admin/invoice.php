<section class="user-dashboard page-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="list-inline dashboard-menu text-center">
                    <li><a href="<?= base_url('admin/dashboard_admin'); ?>">Dashboard</a></li>
					<li><a  href="<?= base_url('admin/data_barang'); ?>">Data Barang</a></li>
					<li><a class="active" href="<?= base_url('admin/invoice'); ?>">Invoice</a></li>
					<li><a href="<?= base_url('admin/order'); ?>">Order</a></li>
				</ul>
				<div class="dashboard-wrapper user-dashboard">
                    <div class="table-responsive">
                        <table class="table">
                        <thead>
                            <tr>
                            <th>Id Invoice</th>
                            <th>Nama Pemesan</th>
                            <th>Alamat Pengiriman</th>
                            <th>Tanggal Pemesanan</th>
                            <th class="col-md-2 col-sm-3">Batas Pembayaran</th>
                            <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($invoice as $inv): 
                            $no= $inv->id *2516;
                            ?>
                            <tr>
                            <td>#<?= $no ?></td>
                            <td><?= $inv->nama ?></td>
                            <td><?= $inv->alamat ?></td>
                            <td><?= $inv->tgl_pesan ?></td>
                            <td><?= $inv->batas_bayar ?></td>
                            <td><?= anchor('admin/invoice/detail/'. $inv->id, '<div class="btn-group" role="group">
                                <button type="button" class="btn btn-default"><i class="tf-ion-eye" aria-hidden="true"></i> Detail</button>
                                </div>') ?>
                            </td>
                            </tr>

                        <?php endforeach; ?>

                        </tbody>
                        </table>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </section>