<section class="user-dashboard page-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="list-inline dashboard-menu text-center">
                    <li><a href="<?= base_url('admin/dashboard_admin'); ?>">Dashboard</a></li>
					<li><a href="<?= base_url('admin/data_barang'); ?>">Data Barang</a></li>
					<li><a href="<?= base_url('admin/invoice'); ?>">Invoice</a></li>
					<li><a class="active" href="<?= base_url('admin/order'); ?>">Order</a></li>
                </ul>
                <h3>Detail pesanan</h3> 
                <div class="btn btn-sm btn-info">No. Invoice: <?php echo $invoice->id ?>
                </div>
				<div class="dashboard-wrapper user-dashboard">
                    <div class="table-responsive">
                        <table class="table">
                        <thead>
                            <tr>
                            <th>Id Pesanan</th>
                            <th>Nama Produk</th>
                            <th>Jumlah Pesanan</th>
                            <th>Harga Satuan</th>
                            <th class="col-md-2 col-sm-3">Subtotal</th>
                            <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total=0;
                            foreach ($pesanan as $psn):
                                $subtotal = $psn->jumlah * $psn->harga;
                                $total += $subtotal;
                                $no= $psn->id_brg * 2516;
                            ?>
                            <tr>
                            <td>#<?= $no ?></td>
                            <td><?= $psn->nama_brg ?></td>
                            <td><?= $psn->jumlah ?></td>
                            <td>Rp. <?= number_format($psn->harga,0,',','.') ?></td>
                            <td>Rp. <?= number_format($subtotal,0,',','.') ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                <button type="button" class="btn btn-default"><i class="tf-pencil2" aria-hidden="true"></i></button>
                                <button type="button" class="btn btn-default"><i class="tf-ion-close" aria-hidden="true"></i></button>
                                </div>
                            </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        </table>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </section>