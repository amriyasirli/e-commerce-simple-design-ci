<section class="user-dashboard page-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="list-inline dashboard-menu text-center">
					<li><a href="<?= base_url('admin/dashboard_admin'); ?>">Dashboard</a></li>
					<li><a class="active" href="<?= base_url('admin/data_barang'); ?>">Data Barang</a></li>
					<li><a href="<?= base_url('admin/invoice'); ?>">Invoice</a></li>
					<li><a href="<?= base_url('admin/order'); ?>">Order</a></li>
				</ul>
				<button type="button"  class="btn btn-main btn-medium btn-round-full  btn-icon" data-toggle="modal" data-target="#tambah_barang"><i class="tf-ion-plus"></i>Tambah Barang</button>
				<div class="dashboard-wrapper user-dashboard">
				
					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th>ID</th>
									<th>NAMA BARANG</th>
									<th>KATEGORI</th>
									<th>HARGA</th>
									<th>STOK</th>
									<th>GAMBAR</th> 
									<th>AKSI</th>
								</tr>
							</thead>
							<?php
							foreach ($barang as $brg) :
								$no= $brg->id_brg * 1997;
								 ?>
							<tbody>
								<tr>
									<td>#<?= $no; ?> </td>
									<td><?= $brg->nama_brg; ?></td>

									<?php if ($brg->kategori == 'Elektronik') : ?>
									<td><span class="label label-primary"><?= $brg->kategori; ?></td>

									<?php elseif ($brg->kategori == 'Pakaian Pria') : ?>
									<td><span class="label label-success"><?= $brg->kategori; ?></td>

									<?php elseif ($brg->kategori == 'Pakaian Wanita') : ?>
									<td><span class="label label-warning"><?= $brg->kategori; ?></td>


									<?php else : ?>
									<td><span class="label label-danger"><?= $brg->kategori; ?></td>

									<?php endif; ?>

									<td>Rp. <?= number_format($brg->harga, 0,',','.') ?></span></td>
									<td><?= $brg->stok; ?></a></td>
									<td><img width="80" src="<?= base_url().'/upload/'. $brg->gambar ?>
									" alt="" /></td>
									

									<td>
										<?php echo anchor('admin/data_barang/view/'. $brg->id_brg, '<div class="btn btn-default"><i class="tf-ion-eye" aria-hidden="true"></i></div>') ?>
										<?php echo anchor('admin/data_barang/edit/'. $brg->id_brg, '<div class="btn btn-default"><i class="tf-pencil2" aria-hidden="true"></i></div>') ?>
										<?php echo anchor('admin/data_barang/hapus_barang/'. $brg->id_brg, '<div class="btn btn-default"><i class="tf-ion-close" aria-hidden="true"></i></div>') ?>
									</td>
								</tr>
							</tbody>

							<?php endforeach; ?>

						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Modal -->
<div class="modal fade" id="tambah_barang" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
		<h3 class="modal-title" id="staticBackdropLabel">Form Tambah Produk</h3>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	  
		<!-- form input -->
		<form action="<?= base_url(). 'admin/data_barang/tambah_aksi';?>" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="nama_brg">Nama Barang</label>
				<input type="text" class="form-control" name="nama_brg" id="nama_brg">
			</div>
			<div class="form-group">
				<label for="keterangan">Keterangan</label>
				<textarea class="form-control" name="keterangan" id="keterangan" rows="4"></textarea>
			</div>
			<div class="form-group">
			<label for="kategori">Kategori</label>
				<select class="form-control" name="kategori" id="kategori">
					<option>Elektronik</option>
					<option>Pakaian Pria</option>
					<option>Pakaian Wanita</option>
					<option>Aksesoris</option>
				</select>
            </div>
			<div class="form-group">
				<label for="harga">Harga</label>
				<input type="number" class="form-control" name="harga" id="harga">
			</div>
			<div class="form-group">
				<label for="stok">Stok</label>
				<input type="number" class="form-control" name="stok" id="stok">
			</div>
			<div class="form-group">
				<label for="gambar">Gambar Barang</label><br>
				<input type="file" class="form-control" name="gambar" id="gambar">
			</div>
		<!-- end form input -->
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-medium btn-round-full  btn-icon" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-main btn-small btn-round-full  btn-icon"><i class="tf-ion-upload"></i>Tambah</button>
	  </div>
	  </form>

    </div>
  </div>
</div>