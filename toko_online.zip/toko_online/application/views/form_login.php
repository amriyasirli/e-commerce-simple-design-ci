<section class="signin-page account">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="block text-center">
          <a class="logo" href="index.html">
            <img src="images/logo.png" alt="">
          </a>
          <h2 class="text-center">Welcome Back</h2>
          <?= $this->session->flashdata('pesan'); ?>
          <form class="text-left clearfix" action="<?= base_url('auth/login') ?>" method="post" >
            <div class="form-group">
              <input type="text" class="form-control" name="username" id="username"  placeholder="Username" required>
            </div>
            <div class="form-group">
              <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-main text-center" >Login</button>
            </div>
          </form>
          <p class="mt-20">Belum punya akun ?<a href="signin.html"> Daftar!</a></p>
        </div>
      </div>
    </div>
  </div>
</section>