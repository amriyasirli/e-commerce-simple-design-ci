<section class="page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="content">
					<h1 class="page-name">Cart</h1>
					<ol class="breadcrumb">
						<li><a href="<?= base_url(); ?>">Home</a></li>
						<li class="active">Cart</li>
					</ol>
				</div>
			</div>
		</div>
	</div>
</section>



<div class="page-wrapper">
  <div class="cart shopping">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="block">
            <div class="product-list">
              <form method="post">
                <table class="table">
                  <thead>
                    <tr>
                      <th class="">Nama Barang</th>
                      <th class="text-center">Jumlah</th>
                      <th class="text-right">Harga</th>
                      <th class="text-right">Sub-Total</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                  $no=1;
                  foreach ($this->cart->contents() as $items) : ?>
                    <tr class="">
                      <td class="">
                        <div class="product-info">
                          <img width="80" src="images/shop/cart/cart-1.jpg" alt="" />
                          <a href=""><?= $items['name'] ?></a>
                        </div>
                      </td>
                      <td class="text-center"><?= $items['qty'] ?></td>
                      <td class="text-right">Rp. <?= number_format($items['price'], 0,',','.') ?></td>
                      <td class="text-right">Rp. <?= number_format($items['subtotal'], 0,',','.') ?></td>
                      <td class="text-center">
                      </td>
                    </tr>
                  <?php endforeach; ?>
                    <tr>
                        <td colspan="3"></td>

                        <td class="text-right"> <div class="badge"><h5>TOTAL = Rp. <?= number_format($this->cart->total(), 0,',','.') ?></h5></td></div>
                    </tr>
                  </tbody>
                </table>
                <div class="text-right">
                    <div class="row mt-30">
                        <div class="col-md-12">
                            <div class="buttonPart">
                            <ul class="list-inline mt-10">
                                <li class="li"><a href="<?= base_url('shop/hapus_keranjang'); ?>" class="btn btn- btn-medium btn-round-full  btn-icon"><i class="tf-ion-ios-trash"></i> Hapus Keranjang</a></li>
                                <li class="li"><a href="<?= base_url('shop/pembayaran'); ?>" class="btn btn-main btn-medium btn-round-full  btn-icon"><i class="tf-ion-ios-cart-outline"></i>Pembayaran</a></li>
                            </ul>
                            </div>
                        </div>		
                    </div>
                </div>
                </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>