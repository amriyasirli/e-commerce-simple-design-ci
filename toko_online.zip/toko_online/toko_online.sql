-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 03 Feb 2020 pada 22.17
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_online`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `gambar`) VALUES
(1, 'amri', 'amri200397', 'fy');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_barang`
--

CREATE TABLE `tb_barang` (
  `id_brg` int(11) NOT NULL,
  `nama_brg` varchar(128) NOT NULL,
  `keterangan` varchar(225) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(5) NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_barang`
--

INSERT INTO `tb_barang` (`id_brg`, `nama_brg`, `keterangan`, `kategori`, `harga`, `stok`, `gambar`) VALUES
(12, 'Sepatu', 'Lorem ipsum dolor sit amet, consectetur adipisicing', 'Pakaian Pria', 300000, 33, 'Desert.jpg'),
(13, 'Speaker Aktif Bluetooth', 'Lorem ipsum dolor sit amet, consectetur adipisicing', 'Elektronik', 150000, 79, 'Lighthouse.jpg'),
(14, 'Jilbab Pasminah', 'Tanpa keterangan untuk produk ini', 'Pakaian Wanita', 70000, 50, 'Tulips.jpg'),
(15, 'TV LED Panasonic', 'Tv led original 100 catoon strecth', 'Elektronik', 2000000, 14, 'Jellyfish.jpg'),
(22, 'proplan salmon adult 7kg', 'Makanan Kucing dewasa', 'Pakaian Pria', 50000, 12, 'proplan2.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_invoice`
--

CREATE TABLE `tb_invoice` (
  `id` int(11) NOT NULL,
  `nama` varchar(56) NOT NULL,
  `alamat` varchar(225) NOT NULL,
  `tgl_pesan` datetime NOT NULL,
  `batas_bayar` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_invoice`
--

INSERT INTO `tb_invoice` (`id`, `nama`, `alamat`, `tgl_pesan`, `batas_bayar`) VALUES
(2, 'yassirli amri', 'Sijunjung', '2020-01-25 13:49:24', '2020-01-26 13:49:24'),
(4, 'Angga', 'Pasaman', '2020-01-25 13:56:40', '2020-01-26 13:56:40'),
(5, 'Rahmat', 'Tanjung Jati', '2020-01-26 01:43:40', '2020-01-27 01:43:40'),
(6, 'Rahmat', 'Tanjung Jati', '2020-01-26 01:49:07', '2020-01-27 01:49:07'),
(7, 'Rahmi', 'Taeh Baruah', '2020-01-26 01:50:56', '2020-01-27 01:50:56'),
(8, 'Angga', 'Pasaman', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'yassirli amri', 'Bukittinggi', '2020-01-26 17:59:05', '2020-01-27 17:59:05'),
(10, 'Arif', 'Bukittinggi', '2020-01-26 22:55:47', '2020-01-27 22:55:47'),
(11, 'heru', 'Bukittinggi', '2020-01-27 12:38:39', '2020-01-28 12:38:40'),
(12, 'Hana', 'Taeh Baruah', '2020-02-02 01:16:29', '2020-02-03 01:16:29');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pesanan`
--

CREATE TABLE `tb_pesanan` (
  `id` int(11) NOT NULL,
  `id_invoice` int(11) NOT NULL,
  `id_brg` int(11) NOT NULL,
  `nama_brg` varchar(128) NOT NULL,
  `jumlah` int(3) NOT NULL,
  `harga` int(10) NOT NULL,
  `pilihan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pesanan`
--

INSERT INTO `tb_pesanan` (`id`, `id_invoice`, `id_brg`, `nama_brg`, `jumlah`, `harga`, `pilihan`) VALUES
(1, 2, 12, 'ff', 1, 3454, ''),
(2, 2, 13, '44', 1, 4564, ''),
(3, 4, 17, 'FASF', 1, 3535, ''),
(4, 5, 12, 'Sepatu', 2, 300000, ''),
(5, 5, 13, 'Baju Koas Oblong', 2, 86000, ''),
(6, 5, 19, 'Jeans Lois', 1, 100000, ''),
(7, 7, 16, 'F', 1, 5445, ''),
(8, 8, 13, 'Speaker Aktif Bluetooth', 1, 150000, ''),
(9, 9, 12, 'Sepatu', 1, 300000, ''),
(10, 10, 21, 'Kaos Supreme', 1, 130000, ''),
(11, 11, 13, 'Speaker Aktif Bluetooth', 1, 150000, ''),
(12, 12, 15, 'TV LED Panasonic', 1, 2000000, '');

--
-- Trigger `tb_pesanan`
--
DELIMITER $$
CREATE TRIGGER `pesanan_penjualan` AFTER INSERT ON `tb_pesanan` FOR EACH ROW BEGIN
UPDATE tb_barang SET stok = stok-NEW.jumlah
WHERE id_brg = NEW.id_brg;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `role_id` tinyint(1) NOT NULL,
  `foto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `role_id`, `foto`) VALUES
(2, 'Yassirli Amri', 'amri', '2516163', 1, ''),
(3, 'Mutia Rahmi', 'rahmi', 'rahmi', 2, '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`id_brg`);

--
-- Indeks untuk tabel `tb_invoice`
--
ALTER TABLE `tb_invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tb_barang`
--
ALTER TABLE `tb_barang`
  MODIFY `id_brg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT untuk tabel `tb_invoice`
--
ALTER TABLE `tb_invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
